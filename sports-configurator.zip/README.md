
[ add following to the package.json to test on wordpress. ]
"homepage": "/sports-configurator/",
