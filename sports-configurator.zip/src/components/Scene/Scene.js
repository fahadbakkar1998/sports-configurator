import React from 'react';
import Scene_Header from './Scene_Header';

const Scene = () => (
  <div className="Scene">
    <Scene_Header></Scene_Header>
  </div>
);

export default Scene;
